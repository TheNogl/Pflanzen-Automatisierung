//ATMega8
//100kbit/s
//F_CPU = 16MHz
//Slave Address ist 0x69
//Luftfeuchtigkeitssensor PD2(LC- Oszillator)
//Bodenfeuchtigkeitssensor PC0
//PORTB f�r LCD Display
//PD0, PD1 USB

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <util/twi.h>
#include "i2c_tasks.h"
#include "TWI_slave.c"

#define SLAVE_READ 0x60
#define SLAVE_WRITE 0xA8
#define NOMINAL_TEMP 20 //Normaltemperatur (data = 100)
#define NOMINAL_F_AIR 100000 //normalfrequenz luftfeuchtigkeitssensor

unsigned char adc_volt_measure(unsigned char kanal); //kanal 0 bis 13 8bit aufl�sung

#define TWI_CMD_MASTER_WRITE 0x10
#define TWI_CMD_MASTER_READ  0x20

// The AVR can be waken up by a TWI address match from all sleep modes,
// But it only wakes up from other TWI interrupts when in idle mode.
// If POWER_MANAGEMENT_ENABLED is defined the device will enter power-down
// mode when waiting for a new command and enter idle mode when waiting
// for TWI receives and transmits to finish.
#define POWER_MANAGEMENT_ENABLED

// Compiler-independent macros (was previously IAR intrinsics)
#if defined(__ICCAVR__)
#define SLEEP()   __sleep()
#else
#define SLEEP()   sleep_cpu()
#endif

// When there has been an error, this function is run and takes care of it
unsigned char TWI_Act_On_Failure_In_Last_Transmission ( unsigned char TWIerrorMsg );

int main( void )
{
    unsigned char TWI_slaveAddress;
    unsigned char datain=0, dataout=0;
    unsigned int frequency=0;
    unsigned char tonred=1, toffred=1, tonblue=1, toffblue=1;
    unsigned char lumred=50, lumblue=50;
    unsigned char timewd=0, timewh=0, timewm=0;
    unsigned char timesd=0, timesh=0, timesm=0;
    unsigned char temp=20;
    // Own TWI slave address
    TWI_slaveAddress = 0x69;

    // Initialise TWI module for slave operation. Include address and/or enable General Call.
    TWI_Slave_Initialise( (unsigned char)((TWI_slaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_GEN_BIT) ));

    sei();

    // Start the TWI transceiver to enable reseption of the first command from the TWI Master.
    TWI_Start_Transceiver();

    // This example is made to work together with the AVR315 TWI Master application note. In adition to connecting the TWI
    // pins, also connect PORTB to the LEDS. The code reads a message as a TWI slave and acts according to if it is a
    // general call, or an address call. If it is an address call, then the first byte is considered a command byte and
    // it then responds differently according to the commands.

    // This loop runs forever. If the TWI is busy the execution will just continue doing other operations.
    while(1)
    {
        // Check if the TWI Transceiver has completed an operation.
        if ( ! TWI_Transceiver_Busy() )
        {
            // Check if the last operation was successful
            if ( TWI_statusReg.lastTransOK )
            {
                // Check if the last operation was a reception
                if ( TWI_statusReg.RxDataInBuf )
                {
                    TWI_Get_Data_From_Transceiver(&datain, 1);
                    // Check if the last operation was a reception as General Call
                    // Example of how to interpret a command and respond.

                    // TWI_CMD_MASTER_WRITE stores the data to PORTB
                    switch(datain)
                    {
                        case MOISTURE:
                            dataout=adc_volt_measure(4);
                            break;

                        /*case TEMP:
                            dataout=adc_temp_measure(1,0);
                            break;*/

                        case AIRMOISTURE:
                            dataout=(char)(frequency/NOMINAL_F_AIR);
                            break;

                        case LUMINOSITY_RED:
                            dataout=lumred;//tonred/(tonred+toffred);
                            break;

                        case LUMINOSITY_BLUE:
                            dataout=tonblue/(tonblue+toffblue);
                            break;

                        case TIME_WATER_D:
                            dataout=timewd;
                            break;

                        case TIME_WATER_H:
                            dataout=timewh;
                            break;

                        case TIME_WATER_M:
                            dataout=timewm;
                            break;

                        case TIME_START_D:
                            dataout=timesd;
                            break;

                        case TIME_START_H:
                            dataout=timesh;
                            break;

                        case TIME_START_M:
                            dataout=timesm;
                            break;

                        case CHANGE_TEMP_1:
                            temp++;
                            dataout=0xAA;
                            break;

                        case CHANGE_TEMP_NEG1:
                            temp--;
                            dataout=0xAB;
                            break;

                        case CHANGE_TEMP_5:
                            temp+=5;
                            dataout=0xAC;
                            break;

                        case CHANGE_TEMP_NEG5:
                            temp-=5;
                            dataout=0xAD;
                            break;

                        case CHANGE_LUMINOSITY_RED_1:
                            if(lumred<100) lumred++;
                            dataout=0xAE;
                            break;

                        case CHANGE_LUMINOSITY_RED_NEG1:
                            if(lumred>0)lumred--;
                            dataout=0xAF;
                            break;

                        case CHANGE_LUMINOSITY_RED_5:
                            if(lumred<96) lumred+=5;
                            else lumred=100;
                            dataout=0xBA;
                            break;

                        case CHANGE_LUMINOSITY_RED_NEG5:
                            if(lumred>5) lumred-=5;
                            else lumred=0;
                            dataout=0xBB;
                            break;

                        case CHANGE_LUMINOSITY_BLUE_1:
                            if(lumblue<100) lumblue++;
                            dataout=0xBC;
                            break;

                        case CHANGE_LUMINOSITY_BLUE_NEG1:
                            if(lumblue>0) lumblue--;
                            dataout=0xBD;
                            break;

                        case CHANGE_LUMINOSITY_BLUE_5:
                            if(lumblue<96) lumblue+=5;
                            else lumblue=100;
                            dataout=0xBE;
                            break;

                        case CHANGE_LUMINOSITY_BLUE_NEG5:
                            if(lumblue>5) lumblue-=5;
                            else lumblue=0;
                            dataout=0xBF;
                            break;
                    }
                    TWI_Start_Transceiver_With_Data(&dataout, 1);
                }
            }
            // Check if the TWI Transceiver has already been started.
            // If not then restart it to prepare it for new receptions.
            if ( ! TWI_Transceiver_Busy() )
            {
                TWI_Start_Transceiver();
            }
        }
        else // Ends up here if the last operation completed unsuccessfully
        {
            TWI_Act_On_Failure_In_Last_Transmission( TWI_Get_State_Info() );
        }

        //Put code here

    }
}



unsigned char TWI_Act_On_Failure_In_Last_Transmission ( unsigned char TWIerrorMsg )
{
    TWI_Start_Transceiver();
    return TWIerrorMsg;
}

unsigned char adc_volt_measure(unsigned char kanal)
{
    unsigned char result=0;
    ADMUX=0;
    ADMUX |= (1<<ADLAR) | kanal;
    ADCSRA |= (1<<ADEN) | (1<<ADPS2) | (1<<ADPS0);
    ADCSRA |= (1<<ADSC);
    while(ADCSRA & (1<<ADSC));
    result=ADCH;
    return result;
}
