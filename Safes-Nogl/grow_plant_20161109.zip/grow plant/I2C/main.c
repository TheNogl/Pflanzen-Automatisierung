//ATMega8
//100kbit/s
//F_CPU = 16MHz
//Slave Address ist 0x69
//Luftfeuchtigkeitssensor PD2(LC- Oszillator)
//Bodenfeuchtigkeitssensor PC0


#include <avr/io.h>
#include <avr/interrupt.h>
#include "i2c_tasks.h"

#define SLAVE_READ_DATA 0x60
#define SLAVE_WRITE 0x01
#define NOMINAL_TEMP 20 //Normaltemperatur (data = 100)
#define NOMINAL_F_AIR 100000 //normalfrequenz luftfeuchtigkeitssensor

char init_spi(unsigned char addr, unsigned int bitrate); //Bitrate in Kbit/s
void slave_send(unsigned char data); //1 Byte wird gesendet
unsigned char slave_read_ack (void); //1 Byte wird eingelesen und erhalt best�tigt
unsigned char slave_action(unsigned char *actiontype); //auszuf�hrende aktion wird abgerufen

unsigned char adc_volt_measure(unsigned char kanal); //kanal 0 bis 13 8bit aufl�sung

/*unsigned char flanks=0;
unsigned char ovf=0;

ISR(TIMER0_OVF_vect)
{
    ovf++;
}

ISR(INT0_vect)
{
    flanks++;
}*/

int main(void)
{
    CLKPR = 0x80;
    CLKPR = 0x00;
    unsigned char datain=0;
    unsigned char dataout=0;
    unsigned char actiontype;
    /*unsigned char tonred=1; //verh�ltnis pwm rote led
    unsigned char toffred=1;//verh�ltnis pwm rote led
    unsigned char tonblue=1; //verh�ltnis pwm blaue led
    unsigned char toffblue=1;//verh�ltnis pwm blaue led
    unsigned int frequencyair=0; //frequenz luftfeuchtigkeit*/
    /*TCCR0B = 0x82;
    OCR0A = 0x40;
    TIMSK0 = 0x03;
    EICRA = 0x03;
    EIMSK = 0x01;
    sei();*/
    init_spi(69, 100);
    //DDRD = 0x80;

    while(1)
    {
        if (slave_action(&actiontype))
        {
            switch(actiontype)
            {
            case SLAVE_READ_DATA:
                datain = slave_read_ack();
                //PORTD |= 0x80;
                actiontype = SLAVE_WRITE;
                break;

            case SLAVE_WRITE:
                slave_send(dataout);
                datain = 0;
                //PORTD&=0x7F;
                actiontype = 0;
                break;
            }
        }
        switch(datain)
        {
        case MOISTURE:
            dataout = adc_volt_measure(0);
            break;

        /*case TEMP:
            dataout = adc_volt_measure(1)/NOMINAL_TEMP*100;
            break;

        case AIRMOISTURE:
            dataout = frequencyair/NOMINAL_F_AIR*100;
            break;

        case LUMINOSITY_RED:
            dataout = tonred/toffred*100;
            break;
        case LUMINOSITY_BLUE:
            dataout = tonblue/toffblue*100;
            break;*/

        }
        /*if(flanks ==100)
        {
            frequencyair=100/(ovf*256+TCNT0);
            ovf=0;
            TCNT0=0;
        }*/
    }

    return 0;
}

char init_spi(unsigned char addr, unsigned int bitrate)
{
    TWBR = ((F_CPU/bitrate)-16)/2;
    if (TWBR < 11) return 0;
    TWAR = (addr << 1);
    TWCR = (1<<TWEN)|(1<<TWEA);
    //PORTD |= 0x80;
    return 1;
}

void slave_send(unsigned char data)
{
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
    while (!(TWCR & (1<<TWINT)));
    TWDR = data;
}

unsigned char slave_read_ack (void)
{
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
    while (!(TWCR & (1<<TWINT)));
    return TWDR;
}

unsigned char slave_action(unsigned char *actiontype)
{
    *actiontype = TWSR&0xF8;
    return TWCR & (1<<TWINT);
}

unsigned char adc_volt_measure(unsigned char kanal)
{
    unsigned char result=0;
    ADMUX=0;
    ADMUX |= (1<<ADLAR) | kanal;
    ADCSRA |= (1<<ADEN) | (1<<ADPS2) | (1<<ADPS0);
    ADCSRA |= (1<<ADSC);
    while(ADCSRA & (1<<ADSC));
    result=ADCH;
    return result;
}
