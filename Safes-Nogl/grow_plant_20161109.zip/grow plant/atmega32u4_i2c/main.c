#include <util/twi.h> 	    //enth�lt z.B. die Bezeichnungen f�r die Statuscodes in TWSR
#include <avr/interrupt.h>
#include <avr/io.h>
#include "twi_slave.h"
#include "twi_slave.c"
#include "i2c_tasks.h"

#define TWI_ADDRESS 0x11

unsigned char adc_volt_measure(unsigned char kanal);

int main(void)
{
    uint8_t response=0;
    uint8_t reg=0;
    unsigned char datamoist[11];
    char i=0, j=0;
    if(!TWIS_Init()) return 0;
    while(1)
    {
        if(TWIS_ResponseRequired(&response))
        {
            switch(response)
            {
            case TW_SR_SLA_ACK:
                reg=TWIS_ReadAck();
                break;
            case TW_ST_SLA_ACK:
                switch(reg)
                {
                    case MOISTURE:
                        TWIS_Write(datamoist[10]);
                        break;
                    case !MOISTURE:
                        TWIS_Write(255);
                        break;
                }
            }
        }
        datamoist[i]=adc_volt_measure(0);
        datamoist[10]=0;
        for(j=0; j<10; j++)
        {
            datamoist[10]+=datamoist[j];
        }
        datamoist[10]=datamoist[10]/10;
        i++;
        if(i==10) i=0;
    }
    TWIS_Stop();
    return 0;
}

unsigned char adc_volt_measure(unsigned char kanal)
{
    unsigned char result=0;
    ADMUX=0;
    ADMUX |= (1<<ADLAR) | kanal;
    ADCSRA |= (1<<ADEN) | (1<<ADPS2) | (1<<ADPS0);
    ADCSRA |= (1<<ADSC);
    while(ADCSRA & (1<<ADSC));
    result=ADCH;
    return result;
}
