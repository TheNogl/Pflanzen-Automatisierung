#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "twi_slave.h"


uint8_t TWIS_Init()
{
	/*
	** Set the TWI slave address
	*/
	TWAR = TWI_ADDRESS;

	/*
	** Activate TWI interface
	*/
	TWSR = 0;
	TWBR = 0;
	TWCR = _BV(TWEN) | _BV(TWEA);
	return 1;
}

void TWIS_Stop()
{
	TWCR = _BV(TWEN) | _BV(TWEA) | _BV(TWINT) | _BV(TWSTO);

	while (TWCR & _BV(TWINT));

	TWCR = _BV(TWEN) | _BV(TWEA);
}

void TWIS_Write(unsigned char byte)
{
	TWDR = byte;
	TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWEA);

	while (!(TWCR & _BV(TWINT)));
}

uint8_t TWIS_ReadAck()
{
	TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWEA);

	while (!(TWCR & _BV(TWINT)));

	return TWDR;
}

uint8_t TWIS_ReadNack()
{
	TWCR = _BV(TWINT) | _BV(TWEN);

	while (!(TWCR & _BV(TWINT)));

	return TWDR;
}

uint8_t TWIS_ResponseRequired(uint8_t *TWI_ResponseType)
{
	if (TWCR & _BV(TWINT))
	{
		*TWI_ResponseType = TW_STATUS;
		return 1;
	}

	return 0;
}
